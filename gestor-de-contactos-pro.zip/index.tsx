
import React, { useState, useEffect, useMemo } from 'react';
import { createRoot } from 'react-dom/client';

// ==========================================
// 1. CONFIGURACIÓN Y TIPOS
// ==========================================

enum ContactStatus {
  SIN_REVISAR = 'sin revisar',
  JUGANDO = 'jugando',
  CONTACTADO = 'contactado',
  NO_INTERESADO = 'no interesado',
  SIN_WSP = 'sin wsp'
}

interface Contact {
  id: string;
  name: string;
  phone: string;
  origin: string;
  status: ContactStatus;
  seenReplied: boolean;
  recovered: boolean;
  interested: boolean;
  lastUpdated: number;
}

const STATUS_CONFIG: Record<ContactStatus, any> = {
  [ContactStatus.SIN_REVISAR]: { label: 'Sin Revisar', color: 'bg-slate-500', borderColor: 'border-slate-500', textColor: 'text-slate-400' },
  [ContactStatus.JUGANDO]: { label: 'Jugando', color: 'bg-purple-600', borderColor: 'border-purple-600', textColor: 'text-purple-400' },
  [ContactStatus.CONTACTADO]: { label: 'Contactado', color: 'bg-emerald-500', borderColor: 'border-emerald-500', textColor: 'text-emerald-400' },
  [ContactStatus.NO_INTERESADO]: { label: 'No Interesado', color: 'bg-rose-500', borderColor: 'border-rose-500', textColor: 'text-rose-400' },
  [ContactStatus.SIN_WSP]: { label: 'Sin WSP', color: 'bg-gray-600', borderColor: 'border-gray-600', textColor: 'text-gray-400' }
};

// ==========================================
// 2. PARSERS (CSV / VCF)
// ==========================================

const parseCSV = (csvText: string): Contact[] => {
  const lines = csvText.split(/\r?\n/);
  if (lines.length < 2) return [];
  
  const headers = lines[0].toLowerCase().split(',').map(h => h.replace(/"/g, '').trim());
  const idxUser = headers.indexOf('usuarios');
  const idxRevStatus = headers.indexOf('estado de revision');
  const idxActualStatus = headers.indexOf('estado actual');
  const idxInterested = headers.indexOf('interesado en jugar?');

  if (idxUser === -1) return [];

  return lines.slice(1).map(line => {
    const cols = line.split(',').map(c => c.replace(/"/g, '').trim());
    const name = cols[idxUser];
    if (!name || name.toLowerCase() === 'eliminado' || name === '') return null;

    const rawRevStatus = cols[idxRevStatus]?.toLowerCase() || '';
    const rawActualStatus = cols[idxActualStatus]?.toLowerCase() || '';
    const rawInterested = cols[idxInterested]?.toLowerCase() || '';

    let status = ContactStatus.SIN_REVISAR;
    if (rawInterested === 'no') status = ContactStatus.NO_INTERESADO;
    else if (rawRevStatus.includes('cargando') || rawRevStatus.includes('esta cargando')) status = ContactStatus.JUGANDO;
    else if (rawActualStatus.includes('contacto') || rawActualStatus.includes('en contacto')) status = ContactStatus.CONTACTADO;
    else if (rawRevStatus.includes('no esta en wsp')) status = ContactStatus.SIN_WSP;

    return {
      id: crypto.randomUUID(),
      name,
      phone: '', 
      origin: 'PLANILLA',
      status,
      seenReplied: cols[4]?.toUpperCase() === 'SI',
      recovered: cols[5]?.toUpperCase() === 'SI',
      interested: rawInterested !== 'no',
      lastUpdated: Date.now()
    };
  }).filter(c => c !== null) as Contact[];
};

const parseVCF = (vcfText: string): Contact[] => {
  const contacts: Contact[] = [];
  vcfText.split(/END:VCARD/i).forEach(block => {
    if (!block.includes('BEGIN:VCARD')) return;
    const name = block.match(/FN:(.+)/i)?.[1].trim() || 'Sin nombre';
    const phone = block.match(/TEL[^:]*:(.+)/i)?.[1].replace(/\D/g, '') || '';
    contacts.push({
      id: crypto.randomUUID(),
      name,
      phone,
      origin: 'PC',
      status: ContactStatus.SIN_REVISAR,
      seenReplied: false, recovered: false, interested: true,
      lastUpdated: Date.now()
    });
  });
  return contacts;
};

// ==========================================
// 3. APP PRINCIPAL
// ==========================================

const App: React.FC = () => {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [viewMode, setViewMode] = useState<'cards' | 'list' | 'tinder'>('cards');
  const [currentFilter, setCurrentFilter] = useState<ContactStatus | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [tinderIndex, setTinderIndex] = useState(0);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [editContact, setEditContact] = useState<Contact | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('gestor_v3_final');
    if (saved) setContacts(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('gestor_v3_final', JSON.stringify(contacts));
  }, [contacts]);

  const stats = useMemo(() => {
    const s: any = { total: contacts.length };
    Object.values(ContactStatus).forEach(v => {
      s[v] = contacts.filter(c => c.status === v).length;
    });
    return s;
  }, [contacts]);

  const filtered = useMemo(() => {
    return contacts.filter(c => {
      const fMatch = currentFilter === 'all' || c.status === currentFilter;
      const sMatch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.phone.includes(searchTerm);
      return fMatch && sMatch;
    });
  }, [contacts, currentFilter, searchTerm]);

  const handleImport = async (e: any, type: 'csv' | 'vcf') => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const newData = type === 'csv' ? parseCSV(text) : parseVCF(text);
    
    setContacts(prev => {
      const map = new Map(prev.map(c => [c.name.toLowerCase(), c]));
      newData.forEach(n => {
        const key = n.name.toLowerCase();
        if (map.has(key)) {
          const existing = map.get(key)!;
          map.set(key, { ...existing, ...n, id: existing.id, phone: existing.phone || n.phone });
        } else {
          map.set(key, n);
        }
      });
      return Array.from(map.values());
    });
    setIsImportOpen(false);
  };

  const exportCSV = () => {
    const headers = ["usuarios", "estado de revision", "", "estado actual", "VISTO, RESPONDIDO?", "RECUPERADO", "TURNO DE LAS CARGAS", "interesado en jugar?", "ya contactados", "recuperados!", "actualmente cargando", "TURNO MAÑANA", "TURNO TARDE", "TURNO NOCHE", "contactos a borrar"];
    const playing = contacts.filter(c => c.status === ContactStatus.JUGANDO).map(c => c.name);
    const contacted = contacts.filter(c => c.status === ContactStatus.CONTACTADO).map(c => c.name);
    const recovered = contacts.filter(c => c.recovered).map(c => c.name);

    const rows = contacts.map((c, i) => [
      c.name,
      c.status === ContactStatus.SIN_WSP ? "no esta en wsp" : (c.status === ContactStatus.JUGANDO ? "esta cargando" : "promo enviada"),
      "",
      c.status === ContactStatus.CONTACTADO || c.status === ContactStatus.JUGANDO ? "EN CONTACTO" : (c.status === ContactStatus.SIN_WSP ? "NO ESTA EN WSP" : "MENSAJE ENVIADO"),
      c.seenReplied ? "SI" : "NO",
      c.recovered ? "SI" : "NO",
      "",
      c.status === ContactStatus.NO_INTERESADO ? "NO" : "SI",
      contacted[i] || "",
      recovered[i] || "",
      playing[i] || "",
      "", "", "", ""
    ].join(','));

    const blob = new Blob([[headers.join(','), ...rows].join('\n')], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `planilla_final.csv`;
    link.click();
  };

  const exportVCF = () => {
    const vcf = contacts.map(c => `BEGIN:VCARD\nVERSION:3.0\nFN:${c.name}\nTEL;TYPE=CELL:${c.phone}\nEND:VCARD`).join('\n\n');
    const blob = new Blob([vcf], { type: 'text/vcard' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `contactos.vcf`;
    link.click();
  };

  const saveEdit = (e: any) => {
    e.preventDefault();
    setContacts(prev => prev.map(c => c.id === editContact?.id ? editContact : c));
    setEditContact(null);
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 p-4 md:p-8 flex flex-col items-center">
      <header className="w-full max-w-5xl flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">GESTOR PRO V3</h1>
          <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Sincronización Total Sheets</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <button onClick={() => setIsImportOpen(true)} className="flex-1 md:flex-none bg-blue-600 hover:bg-blue-500 px-6 py-3 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-blue-900/20">
            <i className="fas fa-file-import"></i> IMPORTAR
          </button>
          <div className="relative group flex-1 md:flex-none">
            <button className="w-full bg-emerald-600 hover:bg-emerald-500 px-6 py-3 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-emerald-900/20">
              <i className="fas fa-download"></i> EXPORTAR
            </button>
            <div className="absolute top-full right-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
              <button onClick={exportCSV} className="w-full p-4 text-left hover:bg-slate-700 rounded-t-2xl flex items-center gap-2 border-b border-slate-700/50"><i className="fas fa-file-csv text-blue-400"></i> Planilla (CSV)</button>
              <button onClick={exportVCF} className="w-full p-4 text-left hover:bg-slate-700 rounded-b-2xl flex items-center gap-2"><i className="fas fa-address-book text-emerald-400"></i> Contactos (VCF)</button>
            </div>
          </div>
          <button onClick={() => confirm('¿Borrar todo?') && setContacts([])} className="bg-slate-800 hover:bg-rose-900 px-4 py-3 rounded-2xl text-slate-500 hover:text-white border border-slate-700 transition-all"><i className="fas fa-trash"></i></button>
        </div>
      </header>

      {/* Stats Filters */}
      <section className="w-full max-w-5xl bg-slate-800/40 border border-slate-700/50 p-6 rounded-[2.5rem] mb-8 shadow-inner">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 mb-6">
          <button onClick={() => setCurrentFilter('all')} className={`p-4 rounded-3xl border transition-all flex flex-col items-center gap-1 ${currentFilter === 'all' ? 'border-blue-500 bg-blue-500/10' : 'border-slate-700'}`}>
            <span className="text-2xl font-black text-white">{stats.total}</span>
            <span className="text-[10px] text-slate-500 font-black uppercase">TOTAL</span>
          </button>
          {Object.values(ContactStatus).map(s => (
            <button key={s} onClick={() => setCurrentFilter(s)} className={`p-4 rounded-3xl border transition-all flex flex-col items-center gap-1 ${currentFilter === s ? STATUS_CONFIG[s].borderColor + ' bg-slate-800 shadow-lg' : 'border-slate-700'}`}>
              <span className={`text-2xl font-black ${STATUS_CONFIG[s].textColor}`}>{stats[s]}</span>
              <span className="text-[10px] text-slate-500 font-black uppercase text-center leading-tight">{STATUS_CONFIG[s].label}</span>
            </button>
          ))}
        </div>
        <div className="h-2.5 bg-slate-900 rounded-full overflow-hidden flex shadow-inner">
          {Object.values(ContactStatus).map(s => (
            <div key={s} style={{ width: `${stats.total ? (stats[s]/stats.total)*100 : 0}%` }} className={`${STATUS_CONFIG[s].color} h-full transition-all duration-700`} />
          ))}
        </div>
      </section>

      {/* Buscador y Vistas */}
      <div className="w-full max-w-5xl flex flex-col md:flex-row gap-4 mb-8">
        <div className="bg-slate-800 p-1.5 rounded-2xl border border-slate-700 flex h-14 md:h-auto shadow-lg">
          <button onClick={() => setViewMode('cards')} className={`flex-1 px-6 py-2 rounded-xl font-black text-xs transition-all ${viewMode === 'cards' ? 'bg-blue-600 shadow-lg text-white' : 'text-slate-500'}`}>CARDS</button>
          <button onClick={() => setViewMode('list')} className={`hidden md:block px-6 py-2 rounded-xl font-black text-xs transition-all ${viewMode === 'list' ? 'bg-blue-600 shadow-lg text-white' : 'text-slate-500'}`}>LISTA</button>
          <button onClick={() => { setViewMode('tinder'); setTinderIndex(0); }} className={`flex-1 px-6 py-2 rounded-xl font-black text-xs transition-all ${viewMode === 'tinder' ? 'bg-rose-600 shadow-lg text-white' : 'text-slate-500'}`}><i className="fas fa-fire mr-1"></i> REVISIÓN</button>
        </div>
        <div className="relative flex-1 group">
          <i className="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors"></i>
          <input type="text" placeholder="Buscar nombre o número..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full h-14 md:h-full bg-slate-800 border border-slate-700 py-4 pl-14 pr-6 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold text-white placeholder-slate-600 transition-all" />
        </div>
      </div>

      {/* Main Content */}
      <main className="w-full max-w-5xl flex-1 pb-20">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 opacity-30 text-center">
            <i className="fas fa-users-slash text-8xl mb-4"></i>
            <h2 className="text-2xl font-black uppercase">Vacío</h2>
          </div>
        ) : (
          <>
            {viewMode === 'cards' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
                {filtered.map(c => (
                  <div key={c.id} className={`bg-slate-800 p-6 rounded-[2.5rem] border-t-8 ${STATUS_CONFIG[c.status].borderColor} shadow-2xl transition-all hover:-translate-y-1`}>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-black text-2xl text-white truncate max-w-[180px]">{c.name}</h3>
                      <div className="flex gap-1">
                        <button onClick={() => setEditContact(c)} className="p-2 text-slate-500 hover:text-blue-400 transition-colors"><i className="fas fa-edit"></i></button>
                        <button onClick={() => confirm('¿Borrar?') && setContacts(prev => prev.filter(x => x.id !== c.id))} className="p-2 text-slate-500 hover:text-rose-500 transition-colors"><i className="fas fa-trash"></i></button>
                      </div>
                    </div>
                    <div className="mb-4 text-[10px] font-black uppercase bg-slate-900/50 inline-block px-3 py-1 rounded-full text-slate-500 border border-slate-700/50">{c.origin}</div>
                    <div className="mb-6 bg-slate-900/50 p-4 rounded-2xl border border-slate-700/30 text-center font-mono text-blue-400 font-black text-lg">{c.phone || 'SIN NÚMERO'}</div>
                    <div className="grid grid-cols-2 gap-2 mb-6">
                      {Object.values(ContactStatus).map(s => (
                        <button key={s} onClick={() => handleStatusChange(c.id, s)} className={`text-[10px] font-black py-2.5 rounded-xl border transition-all ${c.status === s ? STATUS_CONFIG[s].color + ' border-transparent text-white shadow-lg' : 'border-slate-700 text-slate-500 hover:bg-slate-700'}`}>{STATUS_CONFIG[s].label}</button>
                      ))}
                    </div>
                    {c.phone && <a href={`https://wa.me/${c.phone}`} target="_blank" className="w-full bg-emerald-600 hover:bg-emerald-500 py-4 rounded-2xl font-black flex items-center justify-center gap-3 transition-all active:scale-95 shadow-xl shadow-emerald-900/20 text-white"><i className="fab fa-whatsapp text-2xl"></i> WHATSAPP</a>}
                  </div>
                ))}
              </div>
            )}

            {viewMode === 'list' && (
              <div className="hidden md:block bg-slate-800 rounded-[2.5rem] border border-slate-700 overflow-hidden shadow-2xl animate-fadeIn">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-900/50 text-[10px] text-slate-500 uppercase font-black border-b border-slate-700">
                      <th className="px-8 py-6">Usuario</th>
                      <th className="px-8 py-6 text-center">Teléfono</th>
                      <th className="px-8 py-6 text-center">Estado</th>
                      <th className="px-8 py-6 text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    {filtered.map(c => (
                      <tr key={c.id} className="hover:bg-slate-700/30 group">
                        <td className="px-8 py-4"><div className="font-black text-white">{c.name}</div><div className="text-[10px] text-slate-500 uppercase font-bold">{c.origin}</div></td>
                        <td className="px-8 py-4 text-center font-mono text-blue-400 font-bold">{c.phone || '-'}</td>
                        <td className="px-8 py-4 text-center">
                          <select value={c.status} onChange={e => handleStatusChange(c.id, e.target.value as ContactStatus)} className={`bg-slate-900 text-[10px] font-black border rounded-xl px-4 py-2 outline-none appearance-none text-center ${STATUS_CONFIG[c.status].borderColor} ${STATUS_CONFIG[c.status].textColor}`}>
                            {Object.values(ContactStatus).map(s => <option key={s} value={s}>{STATUS_CONFIG[s].label}</option>)}
                          </select>
                        </td>
                        <td className="px-8 py-4 text-right">
                          <div className="flex justify-end gap-1 opacity-60 group-hover:opacity-100 transition-all">
                            {c.phone && <a href={`https://wa.me/${c.phone}`} target="_blank" className="text-emerald-400 p-3 hover:bg-emerald-500/10 rounded-xl transition-all"><i className="fab fa-whatsapp"></i></a>}
                            <button onClick={() => setEditContact(c)} className="text-blue-400 p-3 hover:bg-blue-500/10 rounded-xl transition-all"><i className="fas fa-edit"></i></button>
                            <button onClick={() => confirm('¿Borrar?') && setContacts(prev => prev.filter(x => x.id !== c.id))} className="text-rose-500 p-3 hover:bg-rose-500/10 rounded-xl transition-all"><i className="fas fa-trash"></i></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {viewMode === 'tinder' && filtered[tinderIndex] && (
              <div className="flex flex-col items-center max-w-sm mx-auto pt-6 animate-slideUp">
                <div className={`w-full bg-slate-800 p-10 rounded-[3.5rem] border-t-[12px] ${STATUS_CONFIG[filtered[tinderIndex].status].borderColor} shadow-3xl relative`}>
                  <div className="absolute top-8 right-10 text-slate-600 font-black text-xs tracking-widest">{tinderIndex + 1} / {filtered.length}</div>
                  <div className="mb-10 text-center">
                    <h2 className="text-4xl font-black break-words leading-none mb-4 text-white uppercase tracking-tighter">{filtered[tinderIndex]?.name}</h2>
                    <span className="bg-slate-700 text-slate-300 text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest border border-slate-600">{filtered[tinderIndex]?.origin}</span>
                  </div>
                  <div className="bg-slate-900/80 p-8 rounded-3xl mb-10 border border-slate-700 text-center shadow-inner">
                    <p className="text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest">WhatsApp</p>
                    <p className="text-3xl font-mono text-blue-400 tracking-widest font-black leading-none">{filtered[tinderIndex]?.phone || 'SIN NÚMERO'}</p>
                  </div>
                  {filtered[tinderIndex]?.phone && (
                    <a href={`https://wa.me/${filtered[tinderIndex].phone}`} target="_blank" className="w-full bg-emerald-600 py-6 rounded-3xl font-black text-xl mb-8 flex items-center justify-center gap-4 active:scale-95 transition-all shadow-2xl shadow-emerald-900/40 text-white"><i className="fab fa-whatsapp text-4xl"></i> ABRIR CHAT</a>
                  )}
                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => { handleStatusChange(filtered[tinderIndex].id, ContactStatus.JUGANDO); setTinderIndex(i => (i + 1) % filtered.length); }} className="bg-purple-600 py-5 rounded-2xl font-black text-xs active:scale-95 transition-all shadow-lg uppercase">JUGANDO</button>
                    <button onClick={() => { handleStatusChange(filtered[tinderIndex].id, ContactStatus.CONTACTADO); setTinderIndex(i => (i + 1) % filtered.length); }} className="bg-emerald-500 py-5 rounded-2xl font-black text-xs active:scale-95 transition-all shadow-lg uppercase">CONTACTADO</button>
                    <button onClick={() => { handleStatusChange(filtered[tinderIndex].id, ContactStatus.NO_INTERESADO); setTinderIndex(i => (i + 1) % filtered.length); }} className="bg-rose-500 py-5 rounded-2xl font-black text-xs active:scale-95 transition-all shadow-lg uppercase text-white">NO INTERÉS</button>
                    <button onClick={() => { handleStatusChange(filtered[tinderIndex].id, ContactStatus.SIN_WSP); setTinderIndex(i => (i + 1) % filtered.length); }} className="bg-slate-600 py-5 rounded-2xl font-black text-xs active:scale-95 transition-all shadow-lg uppercase">SIN WSP</button>
                  </div>
                  <div className="flex justify-between mt-10 text-slate-500 font-black text-[10px] uppercase pt-8 border-t border-slate-700/50">
                    <button disabled={tinderIndex === 0} onClick={() => setTinderIndex(i => i - 1)} className="disabled:opacity-20 flex items-center gap-3 px-4 py-2 hover:text-white transition-all"><i className="fas fa-arrow-left"></i> Anterior</button>
                    <button onClick={() => setTinderIndex(i => (i + 1) % filtered.length)} className="flex items-center gap-3 px-4 py-2 hover:text-white transition-all">Siguiente <i className="fas fa-arrow-right"></i></button>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* MODALS */}
      {isImportOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md animate-fadeIn" onClick={() => setIsImportOpen(false)}></div>
          <div className="relative bg-slate-800 border border-slate-700 p-8 rounded-[3.5rem] w-full max-w-md shadow-3xl animate-slideUp">
            <h2 className="text-3xl font-black mb-10 text-center uppercase tracking-tighter text-white">Sincronizar Datos</h2>
            <div className="space-y-4">
              <div className="relative border-4 border-dashed border-slate-700 p-12 rounded-[2.5rem] hover:border-blue-500 text-center cursor-pointer transition-all group overflow-hidden bg-slate-900/30">
                <input type="file" accept=".csv" onChange={e => handleImport(e, 'csv')} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
                <div className="group-hover:scale-110 transition-transform duration-300">
                  <i className="fas fa-file-csv text-6xl text-blue-400 mb-4"></i>
                  <p className="font-black text-white uppercase text-sm">Planilla Sheets</p>
                  <p className="text-[10px] text-slate-500 font-bold mt-2 uppercase tracking-widest italic">Actualiza Estados</p>
                </div>
              </div>
              <div className="relative border-4 border-dashed border-slate-700 p-12 rounded-[2.5rem] hover:border-emerald-500 text-center cursor-pointer transition-all group overflow-hidden bg-slate-900/30">
                <input type="file" accept=".vcf,.vcard" onChange={e => handleImport(e, 'vcf')} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
                <div className="group-hover:scale-110 transition-transform duration-300">
                  <i className="fas fa-address-book text-6xl text-emerald-400 mb-4"></i>
                  <p className="font-black text-white uppercase text-sm">Agenda VCF</p>
                  <p className="text-[10px] text-slate-500 font-bold mt-2 uppercase tracking-widest italic">Importa Números</p>
                </div>
              </div>
            </div>
            <button onClick={() => setIsImportOpen(false)} className="w-full mt-10 py-5 font-black text-slate-500 uppercase text-xs hover:text-white transition-colors tracking-[0.3em]">Cerrar</button>
          </div>
        </div>
      )}

      {editContact && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md animate-fadeIn" onClick={() => setEditContact(null)}></div>
          <form onSubmit={saveEdit} className="relative bg-slate-800 border border-slate-700 p-10 rounded-[3.5rem] w-full max-w-md shadow-3xl animate-slideUp">
            <h2 className="text-3xl font-black mb-10 uppercase tracking-tighter text-white text-center">Editar Perfil</h2>
            <div className="space-y-6">
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase block mb-2 px-2 tracking-widest">Nombre / Usuario</label>
                <input required type="text" value={editContact.name} onChange={e => setEditContact({...editContact, name: e.target.value})} className="w-full bg-slate-900 border border-slate-700 p-5 rounded-2xl outline-none font-black text-white text-xl shadow-inner" />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase block mb-2 px-2 tracking-widest">Número WhatsApp</label>
                <input type="text" value={editContact.phone} onChange={e => setEditContact({...editContact, phone: e.target.value.replace(/\D/g,'')})} className="w-full bg-slate-900 border border-slate-700 p-5 rounded-2xl outline-none font-mono text-blue-400 text-2xl shadow-inner" placeholder="Ej: 351..." />
              </div>
            </div>
            <div className="flex gap-4 mt-12">
              <button type="button" onClick={() => setEditContact(null)} className="flex-1 py-5 font-black text-slate-500 uppercase text-xs hover:bg-slate-700 rounded-2xl transition-all">Cancelar</button>
              <button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-500 py-5 rounded-2xl font-black uppercase text-xs shadow-xl transition-all active:scale-95 text-white">Guardar</button>
            </div>
          </form>
        </div>
      )}

      {/* Flotante Tinder Mobile */}
      {contacts.length > 0 && viewMode !== 'tinder' && (
        <button onClick={() => { setViewMode('tinder'); setTinderIndex(0); }} className="md:hidden fixed bottom-10 right-10 w-24 h-24 bg-rose-600 rounded-full flex items-center justify-center text-white shadow-3xl z-40 border-[10px] border-[#0f172a] active:scale-75 transition-all">
          <i className="fas fa-fire text-4xl"></i>
        </button>
      )}
    </div>
  );

  function handleStatusChange(id: string, newStatus: ContactStatus) {
    setContacts(prev => prev.map(c => c.id === id ? { ...c, status: newStatus, lastUpdated: Date.now() } : c));
  }
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
